-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * --
-- MemeLib
-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * --
group "ML"
project "MemeLib"
	targetname 		"%{prj.name}"
	targetdir		"%{bin_lib}"
	objdir			"%{bin_obj}"
	location		"%{prj_dir}%{prj.name}/"
	language		"C++"
	kind			"StaticLib"
	cppdialect 		"C++17"
	staticruntime	"On"
	systemversion	"latest"
	dependson
	{
		"Vendor",
	}
	defines
	{
		"_CRT_SECURE_NO_WARNINGS",
		"ML_STATIC",
		--"ML_AUDIO_EXPORTS",
		--"ML_CORE_EXPORTS",
		--"ML_EDITOR_EXPORTS",
		--"ML_ENGINE_EXPORTS",
		--"ML_GRAPHICS_EXPORTS",
		--"ML_NETWORK_EXPORTS",
		--"ML_WINDOW_EXPORTS",
	}
	includedirs
	{
		"%{sln_dir}include",
		"%{ext_dir}",
		"%{ext_dir}cpython/include",
		"%{ext_dir}glfw/include",
	}
	files 
	{
		"%{sln_dir}include/ML/Audio/**.**", 	"%{sln_dir}src/ML/Audio/**.**", 
		"%{sln_dir}include/ML/Core/**.**", 		"%{sln_dir}src/ML/Core/**.**", 
		"%{sln_dir}include/ML/Editor/**.**", 	"%{sln_dir}src/ML/Editor/**.**", 
		"%{sln_dir}include/ML/Engine/**.**", 	"%{sln_dir}src/ML/Engine/**.**",  
		"%{sln_dir}include/ML/Graphics/**.**", 	"%{sln_dir}src/ML/Graphics/**.**", 
		"%{sln_dir}include/ML/Network/**.**", 	"%{sln_dir}src/ML/Network/**.**", 
		"%{sln_dir}include/ML/Window/**.**", 	"%{sln_dir}src/ML/Window/**.**", 
	}
	excludes
	{
		"{sln_dir}include/ML/Launcher/**.**",
		"{sln_dir}src/ML/Launcher/**.**",
	}
	libdirs
	{
		"%{bin_lib}", "%{bin_lib}%{cfg.buildcfg}/", "%{bin_lib}%{cfg.buildcfg}/%{cfg.platform}/",
		"%{ext_lib}", "%{ext_lib}%{cfg.buildcfg}/", "%{ext_lib}%{cfg.buildcfg}/%{cfg.platform}/",
	}
	links
	{
		"Vendor",
	}
	
	filter { "configurations:Debug" }
		symbols "On"
		
	filter { "configurations:Release" }
		optimize "Speed"
		
	--filter { "system:Windows" }
	--	postbuildcommands { "xcopy /y %{bin_lib}%{prj.name}.dll %{bin_out}" }


-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * --
-- Launcher
-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * --
group "ML"
project "Launcher"
	targetname 		"ML_%{prj.name}"
	targetdir		"%{bin_lib}"
	objdir			"%{bin_obj}"
	debugdir 		"%{bin_out}"
	location		"%{prj_dir}%{prj.name}/"
	language		"C++"
	cppdialect 		"C++17"
	staticruntime	"On"
	systemversion	"latest"
	dependson
	{
		"MemeLib", "Vendor",
	}
	defines
	{
		"_CRT_SECURE_NO_WARNINGS",
	}
	includedirs
	{
		"%{sln_dir}include",
		"%{ext_dir}",
	}
	files 
	{
		"%{inc_dir}**.h",
		"%{inc_dir}**.hpp",
		"%{inc_dir}**.inl", 
		"%{src_dir}**.c",
		"%{src_dir}**.cpp", 
		"%{sln_dir}ML.ini",
		"%{sln_dir}assets/**.**", 
	}
	libdirs
	{
		"%{bin_lib}", "%{bin_lib}%{cfg.buildcfg}/", "%{bin_lib}%{cfg.buildcfg}/%{cfg.platform}/",
		"%{ext_lib}", "%{ext_lib}%{cfg.buildcfg}/", "%{ext_lib}%{cfg.buildcfg}/%{cfg.platform}/",
	}
	links
	{
		"MemeLib", "Vendor",
	}
	
	filter { "configurations:Debug" }
		symbols "On"
		kind "ConsoleApp"
		
	filter { "configurations:Release" }
		optimize "Speed"
		kind "WindowedApp"
		
	filter { "system:Windows" }
		postbuildcommands 
		{
			"xcopy /y %{bin_lib}ML_%{prj.name}.exe %{bin_out}",
		}


-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * --