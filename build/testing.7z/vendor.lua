-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * --
-- ML_Vendor
-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * --
group "Vendor"
project "Vendor"
	targetname 		"ML_%{prj.name}_%{cfg.buildcfg}_%{cfg.platform}"
	targetdir		"%{bin_lib}"
	objdir			"%{bin_obj}"
	location		"%{prj_dir}%{prj.name}/"
	kind			"StaticLib"
	language		"C++"
	cppdialect 		"C++17"
	staticruntime	"Off"
	systemversion	"latest"
	defines
	{
		"ML_EDITOR_EXPORTS",
		"_CRT_SECURE_NO_WARNINGS",
		"_GLFW_USE_CONFIG_H",
		"_WINSOCK_DEPRECATED_NO_WARNINGS",
		--"ASSIMP_USE_HUNTER",
		--"ASSIMP_BUILD_NO_C4D_IMPORTER",
		--"ASSIMP_BUILD_NO_OPENGEX_IMPORTER",
	}
	includedirs
	{
		"%{sln_dir}include",
		"%{ext_dir}",
		--"%{ext_dir}assimp",
		--"%{ext_dir}assimp/include",
		--"%{ext_dir}assimp/code",
		--"%{ext_dir}openddlparser/include",
		"%{ext_dir}cpython/include",
		"%{ext_dir}glfw/include",
		"%{ext_dir}glfw/src",
	}
	files 
	{
		--"%{ext_dir}assimp/include/**.h",
		--"%{ext_dir}assimp/code/**.h",
		--"%{ext_dir}assimp/code/**.cpp",
		--"%{ext_dir}clipper/**.hpp",
		--"%{ext_dir}clipper/**.cpp",
		"%{ext_dir}glfw/include/glfw/**.h",
		"%{ext_dir}glfw/src/context.c", 
		"%{ext_dir}glfw/src/glfw_config.h", 
		"%{ext_dir}glfw/src/init.c", 
		"%{ext_dir}glfw/src/input.c", 
		"%{ext_dir}glfw/src/internal.h", 
		"%{ext_dir}glfw/src/mappings.h", 
		"%{ext_dir}glfw/src/monitor.c", 
		"%{ext_dir}glfw/src/vulkan.c", 
		"%{ext_dir}glfw/src/window.c",
		"%{ext_dir}imgui/**.h",
		"%{ext_dir}imgui/**.cpp",
		"%{ext_dir}ImGuiColorTextEdit/**.h",
		"%{ext_dir}ImGuiColorTextEdit/**.cpp",
		--"%{ext_dir}irrXML/**.h",
		--"%{ext_dir}irrXML/**.cpp",
		"%{ext_dir}lua/**.h",
		"%{ext_dir}lua/**.hpp",
		"%{ext_dir}lua/**.c",
		--"%{ext_dir}openddlparser/**.h",
		--"%{ext_dir}openddlparser/**.cpp",
		"%{ext_dir}RakNet/**.h",
		"%{ext_dir}RakNet/**.cpp",
		--"%{ext_dir}zip/**.h",
		--"%{ext_dir}zip/**.c",
		--"%{ext_dir}zlib/**.h",
		--"%{ext_dir}zlib/**.c",
	}
	libdirs
	{
		"%{bin_lib}", "%{bin_lib}%{cfg.buildcfg}/", "%{bin_lib}%{cfg.buildcfg}/%{cfg.platform}/",
		"%{ext_lib}", "%{ext_lib}%{cfg.buildcfg}/", "%{ext_lib}%{cfg.buildcfg}/%{cfg.platform}/",
	}
	links
	{
		"assimp",
		"flac", 
		"glew32s",
		"IrrXML", 
		"ogg", 
		"openal32",
		"opengl32",
		"pdcurses",
		"vorbis",
		"vorbisenc",
		"vorbisfile",
		"ws2_32",
		"zlibstatic",
	}
	
	filter { "configurations:Debug" }
		symbols "On"
		links
		{
			"python39_d",
		}
		
	filter { "configurations:Release" }
		optimize "Speed"
		links
		{
			"python39",
		}
		
	filter { "system:Windows", "configurations:Debug" }
		linkoptions
		{
			"/NODEFAULTLIB:MSVCRT.lib",
		}
		
	filter { "system:Windows" }
		linkoptions
		{
			"/bigobj",
		}
		files
		{
			"%{ext_dir}glfw/src/egl_context.c",
			"%{ext_dir}glfw/src/egl_context.h",
			"%{ext_dir}glfw/src/osmesa_context.c",
			"%{ext_dir}glfw/src/osmesa_context.h",
			"%{ext_dir}glfw/src/wgl_context.c",
			"%{ext_dir}glfw/src/wgl_context.h",
			"%{ext_dir}glfw/src/win32_init.c",
			"%{ext_dir}glfw/src/win32_joystick.c",
			"%{ext_dir}glfw/src/win32_joystick.h",
			"%{ext_dir}glfw/src/win32_monitor.c",
			"%{ext_dir}glfw/src/win32_platform.h",
			"%{ext_dir}glfw/src/win32_thread.c",
			"%{ext_dir}glfw/src/win32_time.c",
			"%{ext_dir}glfw/src/win32_window.c",
		}
		postbuildcommands
		{
			--"xcopy /y %{bin_lib}ML_Vendor_%{cfg.buildcfg}_%{cfg.platform}.dll %{bin_out}",
			"xcopy /y %{ext_bin}%{cfg.buildcfg}\\%{cfg.platform}\\assimp.dll %{bin_out}",
			"xcopy /y %{ext_bin}OpenAL32.dll %{bin_out}",
			"if %{cfg.buildcfg} == Debug ( xcopy /y %{ext_bin}%{cfg.buildcfg}\\%{cfg.platform}\\python39_d.dll %{bin_out} )",
			"if %{cfg.buildcfg} == Release ( xcopy /y %{ext_bin}%{cfg.buildcfg}\\%{cfg.platform}\\python39.dll %{bin_out} )",
		}


-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * --